﻿using TidyHPC.LiteDB.Blocks;
using TidyHPC.Semaphores;

namespace TidyHPC.LiteDB.Hashes;

/// <summary>
/// Hash Table
/// <para>hash code -> (hashCode%recordCount) record index</para>
/// <para>record:{hashCode:int,value:long,nextHashRecordAddress:long}</para>
/// </summary>
internal class HashTable : ArrayBlock
{
    /// <summary>
    /// 设置必要信息
    /// </summary>
    /// <param name="address"></param>
    public void SetAddress(long address)
    {
        base.Set(address, HashNode.Size, Database.BlockSize);
    }

    /// <summary>
    /// 获取入口
    /// </summary>
    /// <param name="db"></param>
    /// <param name="globalIndex"></param>
    /// <returns></returns>
    private async Task<HashNode> GetEntry(Database db, ulong globalIndex)
    {
        HashNode result = new();
        int recordIndex = (int)(globalIndex % HashService.HashTableRecordCount);
        await RecordVisitor.ReadByIndex(db, recordIndex, buffer =>
        {
            result = new HashNode(buffer, 0);
        });
        return result;
    }

    /// <summary>
    /// 清除掉Entry上的数据
    /// </summary>
    /// <param name="db"></param>
    /// <param name="globalIndex"></param>
    /// <returns></returns>
    private async Task DeleteEntry(Database db, ulong globalIndex)
    {
        int recordIndex = (int)(globalIndex % HashService.HashTableRecordCount);
        await RecordVisitor.UpdateByIndex(db, recordIndex, buffer =>
        {
            HashNode result = new HashNode(buffer, 0);
            result.HashCode = 0;
            result.Value = 0;
            result.Write(buffer, 0);
            return true;
        });
    }

    /// <summary>
    /// 更新入口
    /// </summary>
    /// <param name="db"></param>
    /// <param name="globalIndex"></param>
    /// <param name="onNode"></param>
    /// <returns></returns>
    private async Task UpdateEntry(Database db, ulong globalIndex, Func<HashNode, Task<(bool,HashNode)>> onNode)
    {
        int recordIndex = (int)(globalIndex % HashService.HashTableRecordCount);
        await RecordVisitor.UpdateByIndex(db, recordIndex, async buffer =>
        {
            var node = new HashNode(buffer, 0);
            if ((await onNode(node)) is (true, HashNode newNode))
            {
                newNode.Write(buffer, 0);
                return true;
            }
            return false;
        });
    }

    /// <summary>
    /// 更新入口
    /// </summary>
    /// <param name="db"></param>
    /// <param name="globalIndex"></param>
    /// <param name="onNode"></param>
    /// <returns></returns>
    private async Task UpdateEntry(Database db, ulong globalIndex, Func<HashNode, (bool, HashNode)> onNode)
    {
        int recordIndex = (int)(globalIndex % HashService.HashTableRecordCount);
        await RecordVisitor.UpdateByIndex(db, recordIndex,buffer =>
        {
            var node = new HashNode(buffer, 0);
            if (onNode(node) is (true, HashNode newNode))
            {
                newNode.Write(buffer, 0);
                return true;
            }
            return false;
        });
    }

    /// <summary>
    /// 获取
    /// </summary>
    /// <param name="db"></param>
    /// <param name="hashCode"></param>
    /// <param name="equals"></param>
    /// <returns></returns>
    public async Task<HashResult> Get(Database db,ulong hashCode,Func<long,Task<bool>> equals)
    {
        HashResult result = new();
        ulong globalIndex = hashCode;
        var node = await GetEntry(db, globalIndex);
        globalIndex /= HashService.HashTableRecordCount;

        if (node.HashCode == hashCode && await equals(node.Value))
        {
            result.Success = true;
            result.Value = node.Value;
            return result;
        }

        HashBlock hashBlock = await db.Cache.HashBlockPool.Dequeue();
        while (true)
        {
            var nextBlockAddress = Database.GetBlockAddress(node.NextHashRecordAddress);
            hashBlock.Set(nextBlockAddress);
            await hashBlock.RecordVisitor.Read(db, node.NextHashRecordAddress, buffer =>
            {
                var hashRecord = new HashRecord(buffer, 0);
                node = hashRecord.GetNode(globalIndex);
                globalIndex /= HashService.HashRecordNodeCount;
            });
            if (node.HashCode == hashCode && await equals(node.Value))
            {
                result.Success = true;
                result.Value = node.Value;
                break;
            }
            if (node.NextHashRecordAddress == 0)
            {
                break;
            }
        }
        db.Cache.HashBlockPool.Enqueue(hashBlock);
        return result;
    }

    /// <summary>
    /// 是否包含某个值
    /// </summary>
    /// <param name="db"></param>
    /// <param name="hashCode"></param>
    /// <param name="value"></param>
    /// <returns></returns>
    public async Task<bool> Contains(Database db, ulong hashCode,long value)
    {
        var result = await Get(db, hashCode, async item =>
        {
            await Task.CompletedTask;
            return item == value;
        });
        return result.Success;
    }

    public async Task Update(Database db,ulong hashCode,Func<long, Task<bool>> equals,Func<Task<long>> onNew,Func<long,Task<long>>? onUpdate)
    {
        bool isUpdated = false;
        HashNodeMessage canWriteNode = new();
        bool isEntryCanWrite = false;
        ulong globalIndex = hashCode;
        ulong entryGlobalIndex = globalIndex;
        long nextHashRecordAddress = 0;
        await UpdateEntry(db, entryGlobalIndex, async item =>
        {
            nextHashRecordAddress = item.NextHashRecordAddress;
            if (item.HashCode == hashCode && await equals(item.Value))
            {
                //目标值已经存在
                isUpdated = true;
                if (onUpdate != null)
                {
                    //更新目标值，所以返回true，表示已经更新，将数据写入
                    var oldValue = item.Value;
                    item.Value = await onUpdate(item.Value);
                    return (oldValue != item.Value, item);
                }
                else
                {
                    //不需要更新，所以返回false，不写入数据
                    return (false, default);
                }
            }
            else if (item.HashCode == 0 && item.NextHashRecordAddress == 0)
            {
                //当前节点为空且没有下一个节点
                //所以该值不存在，需要新建
                //而且可以直接写入
                isUpdated = true;
                item.HashCode = hashCode;
                item.Value = await onNew();
                return (true, item);
            }
            else if (item.HashCode == 0 && item.NextHashRecordAddress != 0)
            {
                //当前节点为空，但是不确定后续是否存在目标值的节点
                //表明当前入口节点可以写入
                //当后续找不到目标值时，可以直接写入
                isEntryCanWrite = true;
            }
            return (false, default);
        });
        if (isUpdated)
        {
            return;
        }
        HashBlock hashBlock = await db.Cache.HashBlockPool.Dequeue();
        if (nextHashRecordAddress == 0)
        {
            //申请新的HashRecord
            nextHashRecordAddress = await db.AllocateHashRecord();
            //将数据反写
            await UpdateEntry(db, entryGlobalIndex, item =>
            {
                item.NextHashRecordAddress = nextHashRecordAddress;
                return (true, item);
            });
        }

        globalIndex /= HashService.HashTableRecordCount;
        while (true)
        {
            var currentHashRecordAddress = nextHashRecordAddress;
            hashBlock.SetByRecordAddress(currentHashRecordAddress);
            var nodeOffset = HashRecord.GetNodeOffset(globalIndex);
            await hashBlock.RecordVisitor.UpdateSpan(db, currentHashRecordAddress, nodeOffset, HashNode.Size, async buffer =>
            {
                HashNode node = new(buffer, 0);
                nextHashRecordAddress = node.NextHashRecordAddress;
                if (node.HashCode == hashCode && await equals(node.Value))
                {
                    //目标值已经存在
                    isUpdated = true;
                    if (onUpdate != null)
                    {
                        //更新目标值，所以返回true，表示已经更新，将数据写入
                        var oldValue = node.Value;
                        node.Value = await onUpdate(node.Value);
                        if (oldValue != node.Value)
                        {
                            node.Write(buffer, 0);
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        //不需要更新，所以返回false，不写入数据
                        return false;
                    }
                }
                else if (node.HashCode == 0 && node.NextHashRecordAddress == 0)
                {
                    //当前节点为空且没有下一个节点
                    //所以该值不存在，需要新建
                    //而且可以直接写入
                    isUpdated = true;
                    node.HashCode = hashCode;
                    node.Value = await onNew();
                    node.Write(buffer, 0);
                    return true;
                }
                else if (isEntryCanWrite == false && canWriteNode.Success == false && node.HashCode == 0 && node.NextHashRecordAddress != 0)
                {
                    //当前节点为空，但是不确定后续是否存在目标值的节点
                    //表明当前节点可以写入
                    //当后续找不到目标值时，可以直接写入
                    canWriteNode.Success = true;
                    canWriteNode.HashRecordAddress = currentHashRecordAddress;
                    canWriteNode.NodeOffset = nodeOffset;
                }
                return false;
            });
            if (isUpdated)
            {
                break;
            }
            if (nextHashRecordAddress == 0)
            {
                //已经到最后了，但是还是没有找到目标值
                if (isEntryCanWrite)
                {
                    //直接写入到入口
                    await UpdateEntry(db, entryGlobalIndex, async item =>
                    {
                        item.HashCode = hashCode;
                        item.Value = await onNew();
                        return (true, default);
                    });
                    break;
                }
                else
                {
                    //需要新建HashRecord，由下一次循环处理
                    nextHashRecordAddress = await db.AllocateHashRecord();
                    //将数据反写
                    await hashBlock.RecordVisitor.UpdateSpan(db, currentHashRecordAddress, nodeOffset, HashNode.Size, buffer =>
                    {
                        HashNode node = new(buffer, 0);
                        node.NextHashRecordAddress = nextHashRecordAddress;
                        node.Write(buffer, 0);
                        return true;
                    });
                }
            }
            globalIndex /= HashService.HashRecordNodeCount;
        }
        db.Cache.HashBlockPool.Enqueue(hashBlock);
    }

    public async Task Remove(Database db, ulong hashCode, Func<long, Task<bool>> equals)
    {
        ulong globalIndex = hashCode;
        var node = await GetEntry(db, globalIndex);
        if (node.HashCode == hashCode && await equals(node.Value))
        {
            await DeleteEntry(db, globalIndex);
            return;
        }
        globalIndex /= HashService.HashTableRecordCount;

        HashBlock hashBlock = await db.Cache.HashBlockPool.Dequeue();
        while (true)
        {
            if (node.NextHashRecordAddress == 0)
            {
                break;
            }
            var currentHashRecordAddress = node.NextHashRecordAddress;
            hashBlock.SetByRecordAddress(currentHashRecordAddress);
            await hashBlock.RecordVisitor.Read(db, currentHashRecordAddress, buffer =>
            {
                var hashRecord = new HashRecord(buffer, 0);
                node = hashRecord.GetNode(globalIndex);
            });
            if (node.HashCode == hashCode && await equals(node.Value))
            {
                await hashBlock.RecordVisitor.Update(db, currentHashRecordAddress, buffer =>
                {
                    var hashRecord = new HashRecord(buffer, 0);
                    node.Value = 0;
                    node.HashCode = 0;
                    hashRecord.SetNode(globalIndex, node);
                    return true;
                });
                break;
            }
            globalIndex /= HashService.HashRecordNodeCount;
        }
        db.Cache.HashBlockPool.Enqueue(hashBlock);
    }

    public async Task GetValues(Database db)
    {
        var entryCount = RecordCount;
        var hashNodeSize = RecordSize;
        List<HashNode> entryNodes = [];
        List<long> values = [];
        await RecordRegionVisitor.Read(db, buffer =>
        {
            for (int i = 0; i < entryCount; i++)
            {
                var node = new HashNode(buffer, i * hashNodeSize);
                if (node.HashCode != 0)
                {
                    entryNodes.Add(node);
                    values.Add(node.Value);
                }
            }
        });
    }
}

internal struct HashResult
{
    public bool Success { get; set; }

    public long Value;
}

/// <summary>
/// Hash Node 相关信息
/// </summary>
internal struct HashNodeMessage
{
    public bool Success;

    public long HashRecordAddress;

    public int NodeOffset;
}