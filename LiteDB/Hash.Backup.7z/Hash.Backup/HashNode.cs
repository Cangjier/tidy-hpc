﻿namespace TidyHPC.LiteDB.Hashes;

/// <summary>
/// Hash Node
/// </summary>
/// <remarks>
/// Constructor
/// </remarks>
/// <param name="buffer"></param>
/// <param name="offset"></param>
public struct HashNode(byte[] buffer, int offset)
{
    /// <summary>
    /// Hash Code
    /// </summary>
    public ulong HashCode = BitConverter.ToUInt64(buffer, offset);

    /// <summary>
    /// Value
    /// </summary>
    public long Value = BitConverter.ToInt64(buffer, offset + sizeof(ulong));

    /// <summary>
    /// Next Hash Record Address
    /// </summary>
    public long NextHashRecordAddress = BitConverter.ToInt64(buffer, offset + sizeof(ulong) + sizeof(long));

    /// <summary>
    /// Size of Hash Node
    /// </summary>
    public const int Size = sizeof(ulong) + sizeof(long) + sizeof(long);

    /// <summary>
    /// 将Hash Node写入buffer
    /// </summary>
    /// <param name="buffer"></param>
    /// <param name="offset"></param>
    public void Write(byte[] buffer, int offset)
    {
        BitConverter.GetBytes(HashCode).CopyTo(buffer, offset);
        BitConverter.GetBytes(Value).CopyTo(buffer, offset + sizeof(ulong));
        BitConverter.GetBytes(NextHashRecordAddress).CopyTo(buffer, offset + sizeof(ulong) + sizeof(long));
    }
}
