﻿using TidyHPC.LiteDB.Blocks;

namespace TidyHPC.LiteDB.Hashes;

/// <summary>
/// Hask记录块
/// </summary>
internal class HashBlock : StatisticalBlock
{
    /// <summary>
    /// 设置必要信息
    /// </summary>
    /// <param name="address"></param>
    public void Set(long address)
    {
        Set(address, HashRecord.Size, Database.BlockSize);
    }

    /// <summary>
    /// 根据记录地址设置必要信息
    /// </summary>
    /// <param name="address"></param>
    public void SetByRecordAddress(long address)
    {
        SetByRecordAddress(address, HashRecord.Size);
    }
}
