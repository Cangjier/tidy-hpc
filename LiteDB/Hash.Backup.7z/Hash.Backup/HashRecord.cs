﻿namespace TidyHPC.LiteDB.Hashes;

/// <summary>
/// Hash记录
/// </summary>
public struct HashRecord(byte[] buffer, int offset)
{
    /// <summary>
    /// Record Data
    /// </summary>
    public byte[] Buffer = buffer;

    /// <summary>
    /// Data Offset
    /// </summary>
    public int Offset = offset;

    /// <summary>
    /// Get Hash Node
    /// </summary>
    /// <param name="globalIndex"></param>
    /// <returns></returns>
    public readonly HashNode GetNode(ulong globalIndex)
    {
        var index = (int)(globalIndex % HashService.HashRecordNodeCount);
        return new HashNode(Buffer, Offset + index * HashNode.Size);
    }

    /// <summary>
    /// Set Hash Node
    /// </summary>
    /// <param name="globalIndex"></param>
    /// <param name="node"></param>
    public readonly void SetNode(ulong globalIndex, HashNode node)
    {
        var index = (int)(globalIndex % HashService.HashRecordNodeCount);
        var nodeOffset = Offset + index * HashNode.Size;
        BitConverter.GetBytes(node.HashCode).CopyTo(Buffer, nodeOffset);
        BitConverter.GetBytes(node.Value).CopyTo(Buffer, nodeOffset + sizeof(ulong));
        BitConverter.GetBytes(node.NextHashRecordAddress).CopyTo(Buffer, nodeOffset + sizeof(ulong) + sizeof(long));
    }

    /// <summary>
    /// Size of Hash Record
    /// </summary>
    public const int Size = HashService.HashRecordNodeCount * HashNode.Size;

    /// <summary>
    /// 获取Node索引
    /// </summary>
    /// <param name="globalIndex"></param>
    /// <returns></returns>
    public static int GetNodeIndex(ulong globalIndex)
    {
        return (int)(globalIndex % HashService.HashRecordNodeCount);
    }

    /// <summary>
    /// 获取Node偏移
    /// </summary>
    /// <param name="globalIndex"></param>
    /// <returns></returns>
    public static int GetNodeOffset(ulong globalIndex)
    {
        return GetNodeIndex(globalIndex) * HashNode.Size;
    }
}
